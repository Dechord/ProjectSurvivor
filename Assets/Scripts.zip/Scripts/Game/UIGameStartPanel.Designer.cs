// Generate Id:5ee52a83-f964-4cca-81ca-2c23f61d96b0
using UnityEngine;

namespace ProjectSurvivor
{
	public partial class UIGameStartPanel
	{

		public UnityEngine.UI.Button BtnCoinUpgrade;

		public UnityEngine.UI.Button BtnGameStart;

		public RectTransform CoinUpgradePanel;

	}
}
