// Generate Id:2f3c56b0-20ea-431a-88e4-1bf5160ece55
using UnityEngine;

namespace ProjectSurvivor
{
	public partial class CollectableArea
	{

	}
}
