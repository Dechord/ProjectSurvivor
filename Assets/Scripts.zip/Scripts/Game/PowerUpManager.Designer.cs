// Generate Id:a2fa2742-2fdf-479e-a52a-df4c72468b80
using UnityEngine;

namespace ProjectSurvivor
{
	public partial class PowerUpManager
	{

		public ProjectSurvivor.Exp Exp;

		public ProjectSurvivor.Coin Coin;

	}
}
