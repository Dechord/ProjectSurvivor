// Generate Id:c1451cc7-be37-4900-8d19-e766045cb089
using UnityEngine;

namespace ProjectSurvivor
{
	public partial class CoinUpgradePanel
	{

		public UnityEngine.UI.Button BtnExpPercentUpgrade;

		public UnityEngine.UI.Button BtnCoinPercentUpgrade;

		public UnityEngine.UI.Button BtnCoinPanelClose;

		public UnityEngine.UI.Text CoinText;

	}
}
