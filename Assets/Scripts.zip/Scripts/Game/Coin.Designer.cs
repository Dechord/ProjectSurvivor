// Generate Id:682ebb72-c02d-4ad7-8e15-36bb9a1d0168
using UnityEngine;

namespace ProjectSurvivor
{
	public partial class Coin
	{

	}
}
