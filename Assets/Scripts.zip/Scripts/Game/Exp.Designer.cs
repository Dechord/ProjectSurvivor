// Generate Id:683a1695-e92c-49a3-9043-b6c6e8770433
using UnityEngine;

namespace ProjectSurvivor
{
	public partial class Exp
	{

	}
}
