// Generate Id:1064afc9-88e4-425f-9256-55fb0bc0f673
using UnityEngine;

namespace ProjectSurvivor
{
	public partial class GameUIController
	{

	}
}
