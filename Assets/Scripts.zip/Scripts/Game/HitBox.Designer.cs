// Generate Id:c2922e6c-172e-402b-9344-5d0268f6b82d
using UnityEngine;

namespace ProjectSurvivor
{
	public partial class HitBox
	{

	}
}
