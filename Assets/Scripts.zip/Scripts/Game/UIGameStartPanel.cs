using UnityEngine;
using QFramework;

namespace ProjectSurvivor
{
	public partial class UIGameStartPanel : ViewController
	{
		void Start()
		{
			// Code Here
		}
	}
}
