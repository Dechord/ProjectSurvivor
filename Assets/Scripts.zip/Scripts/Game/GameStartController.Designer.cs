// Generate Id:8154beb9-1efa-47db-a5e1-e31ec5a4da4c
using UnityEngine;

namespace ProjectSurvivor
{
	public partial class GameStartController
	{

	}
}
