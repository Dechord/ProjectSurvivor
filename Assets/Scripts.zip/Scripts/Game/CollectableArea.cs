using UnityEngine;
using QFramework;

namespace ProjectSurvivor
{
	public partial class CollectableArea : ViewController
	{
		void Start()
		{
			// Code Here
		}
	}
}
