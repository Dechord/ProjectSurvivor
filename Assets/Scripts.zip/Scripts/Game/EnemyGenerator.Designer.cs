// Generate Id:12b888f8-5cc6-40c3-be61-cb4471bfa203
using UnityEngine;

namespace ProjectSurvivor
{
	public partial class EnemyGenerator
	{

		public ProjectSurvivor.Enemy Enemy;

	}
}
