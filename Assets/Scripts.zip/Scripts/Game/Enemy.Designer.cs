// Generate Id:d48cb84b-643d-48d9-9db3-13959265d3a1
using UnityEngine;

namespace ProjectSurvivor
{
	public partial class Enemy
	{

		public SpriteRenderer Sprite;

	}
}
