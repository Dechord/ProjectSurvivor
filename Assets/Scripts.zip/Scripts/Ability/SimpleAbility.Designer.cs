// Generate Id:1f944d1c-79f5-404f-84d8-844129d6d799
using UnityEngine;

namespace ProjectSurvivor
{
	public partial class SimpleAbility
	{

		public UnityEngine.CircleCollider2D abilityCircleCollider2D;

	}
}
